#===============================================================================
# Script: PPAHomeRange.R
# Purpose: Calculate PPA home range in R
#     1. Requires a suitable telemetry datasets (class: ltraj)
#     2. Requires selection of an appropriate vmax parameter
#
# Output: An object of class SpatialPolygon delineating the PPA home range
#
# For additional information on this method see the article:
#   Long, JA, Nelson, TA. 2012. Time geography and wildlife home range
#       delineation. Journal of Wildlife Management. 76(2):407-413.
#
#
# Code by: Jed Long
# Date: March 2012
#===============================================================================

#Additional Notes:
# This package creates two functions that operate within the R environment
# the PPAHomeRange function is of most interest.  The other function is the
# ppaEllipse function which contains the code for drawing the PPA ellipses. This
# code can be modified to provide more detailed or coarse Ellipses by changing 
# the number of segments used in this drawing. The default for this is 360.

#this function depends on 3 libraries that must be installed
# I think this is the wrong place to put these warning messages...
#if(!require(adehabitatLT)) stop("Package adehabitatLT required")
#if(!require(rgeos) stop("Package rgeos required")
#if(!require(sp) stop("Package sp required")

#perhaps set option quietly=T
library(adehabitatLT)
library(rgeos)
library(sp)

#===============================================================================
# function: ppaEllipse
# purpose: Calculate Time geography ellipses
#---------------------------------------------------------------
#x,y are center points
#a,b are semi-major and semi-minor axis
#theta is rotation angle (in radians)
#steps is number of segments to draw (default: 360)
# This formulation uses the general parametric form of an ellipse
ppaEllipse <- function(x,y,a,b,theta,steps){
  X=rep(0,steps);Y=rep(0,steps)
  sinTheta <- sin(theta)
  cosTheta <- cos(theta)
  
  for (i in 1:steps){
    alpha <- i*(360/steps)*(pi/180)
    sinAlpha <- sin(alpha)
    cosAlpha <- cos(alpha)
    X[i] = x + (a*cosAlpha*cosTheta - b*sinAlpha*sinTheta)
    Y[i] = y + (a*cosAlpha*sinTheta + b*sinAlpha*cosTheta)
    }
  #save X,Y as Points Data frame
  ptDF <- data.frame(x=X,y=Y)
  ptDF[steps+1,] <- ptDF[1,]     #add first point to end to close ellipse
  #turn ellipses from points to polygons
  ellipsePoly <- Polygon(ptDF,hole=F)
  return(ellipsePoly)
  }
#End of Function  
#===============================================================================

#===============================================================================
# function: PPAHomeRange
# purpose: compute ppa home range on animal telemetry data
# Notes: in development
#-----------------------------------------------------------------------
PPAHomeRange <- function(traj, method="Robson", k=5, manualVmax=0,tol=max(traj[[1]]$dt, na.rm=T),ePoints=360){

  #Hacked check to see if ltraj is not a type II
  checker <- class(traj[[1]]$date[1])
  if (checker[1] == "integer") {stop("The trajectory object is not a TypeII ltraj object")}
  
  #store trajectory data as a dataframe for indexing
  trDF <- traj[[1]]
  nRelocs <- dim(trDF)[1]
  nEllips <- nRelocs - 1
  
  #----------------------------------------------
  # Determine vMax parameter, relies on
  # input from the user to select method or to 
  # set a manual value.
  #----------------------------------------------
  vRaw <- traj[[1]]$dist / traj[[1]]$dt
  v <- sort(vRaw, decreasing = T)
  vMax <- switch(method,
          #Robson & Whitlock (1964) method --- main estimate and UL come
          # directly from the paper, however the LL was inferred
          Robson = v[1] + (v[1]-v[2]),
          RobsonLL = v[1] + ((1-(1-alpha))/(1-alpha))*(v[1]-v[2]),
          RobsonUL = v[1] + ((1-alpha)/alpha)*(v[1]-v[2]),
          #van der Watt (1980) method --- all come directly from the paper.
          vanderWatt = (((k+2)/(k+1))*v[1]) - ((1/(k+1))*v[k]),
          vanderWattLL = v[1] + ((1-(1-alpha)^(1/k))^(-1)-1)^(-1)*(v[1]-v[k]),
          vanderWattUL = v[1] + ((1-(alpha)^(1/k))^(-1)-1)^(-1)*(v[1]-v[k]),
          #Manual method
          manual = manualVmax,
          stop(paste("The vMax method is spelt incorrectly: ",method)))

  print(paste("The value of the vMax parameter using the ",
               method, " method is: ", vMax, sep=""))
  if(vMax <= v[1]){stop(paste("The vMax value of ",vMax," is too small!",sep=""))}
  #-----------------------------------------------
  
  #loop through trajectory dataset and calculate PPA
  polyList <- list()
  for (i in 1:nEllips){
    if (trDF$dt[i] <= tol){
      cpX <- (trDF$x[i] + trDF$x[i+1])/2
      cpY <- (trDF$y[i] + trDF$y[i+1])/2
      #check to see if the angle is NA, if it is make it zero (no movement)
      if (is.na(trDF$abs.angle[i]) == TRUE) {
        thetaRot <- 0
        } else {thetaRot <- trDF$abs.angle[i]}
      c <- trDF$dist[i]/2
      a <- (trDF$dt[i]*vMax)/2
      b <- sqrt((a^2)-(c^2))
  
      #Compute the ellipse
      polyList[i] <- ppaEllipse(cpX,cpY,a,b,thetaRot,ePoints)
      }
    }
  
  #---------------------------------------------
  # Create spatial polygons from the output
  #---------------------------------------------
  ind.poly <- which(lapply(polyList, is.null) == F)
  polyList <- polyList[ind.poly]
  tempPoly <- Polygons(polyList,"PPAHR")
  spPoly <- SpatialPolygons(list(tempPoly),1:1)
  
  #"union" multiple spatial polygons stored in single sp object
  #(dissolve in GIS)  
  spUnion <- gUnionCascaded(spPoly)
  return(spUnion)
  }
  #End of Function
#===============================================================================

  



