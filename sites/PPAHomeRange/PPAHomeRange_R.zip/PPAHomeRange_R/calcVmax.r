#===============================================================================
# calcVmax.R
# Purpose: Calculates different estimates for the Vmax parameter as described in
#             Long and Nelson (2012) for comparison.
#
#           Long, JA, and Nelson, TA. 2012. Time geography and wildlife  home
#             range delineation. Journal of Wildlife Management. 76(2):407-413.
# by: Jed Long
# Date: March, 2012
#===============================================================================

#perhaps set option quietly=T
library(adehabitatLT)
calcVmax <- function(traj,k=5,alpha=0.05){
  #----------------------------------------------
  # Determine vMax parameter, relies on
  # input from the user to select method or to
  # set a manual value.
  #----------------------------------------------
  vRaw <- traj[[1]]$dist / traj[[1]]$dt
  v <- sort(vRaw, decreasing = T)
            #Robson & Whitlock (1964) method --- main estimate and UL come
              # directly from the paper, however the LL was inferred
            R = v[1] + (v[1]-v[2])
            RLL = v[1] + ((1-(1-alpha))/(1-alpha))*(v[1]-v[2])
            RUL = v[1] + ((1-alpha)/alpha)*(v[1]-v[2])
            #van der Watt (1980) method --- all come directly from the paper.
            VW = (((k+2)/(k+1))*v[1]) - ((1/(k+1))*v[k])
            VWLL = v[1] + ((1-(1-alpha)^(1/k))^(-1)-1)^(-1)*(v[1]-v[k])
            VWUL = v[1] + ((1-(alpha)^(1/k))^(-1)-1)^(-1)*(v[1]-v[k])
            
  output <- data.frame(method=c("Robson & Whitlock (1964)","van der Watt (1980)"),
                       lower.limit = c(RLL,VWLL),estimate=c(R,VW),upper.limit=c(RUL,VWUL))
  return(output)
  }

#============= End =============================================================
