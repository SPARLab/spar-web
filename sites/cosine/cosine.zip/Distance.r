rm(list = ls(all = TRUE))#CLEAR ALL

#-----------------------------------------------
# Load libraries to run R-code
#-----------------------------------------------
require(maptools)
require(raster)
require(spdep)
require(sp)
require(geoR)
require(igraph)
require(spatstat)
require(gtools)
require(rgeos)
require(SDMTools)
require(rgdal)
require(fgui)

#***************************************************************************
# First section is to look for the path and establish the working directory. 
# From there:
# 'getDirNFile' will look for the path (regular windows path) and remove 
# '.shp' extension
#***************************************************************************
getDirNFile <- function(inputFileDir ){
  #GET AND SET ROOT DIR AND FILE DIR
  DIR=unlist(strsplit(inputFileDir,"",fixed = TRUE))
  TokenPos=1:length(DIR)
  TokenPosMatch=TokenPos[DIR=="\\"]
  rootDir=paste0(DIR[1:TokenPosMatch[length(TokenPosMatch)]],collapse="")
  fileDir=paste0(DIR[(TokenPosMatch[length(TokenPosMatch)]+1):(length(DIR)-4)],collapse="") #remove '.shp' extension from the path
  setwd(rootDir)   #setup a working directory (i.e. where data are saved)
  
  return(c(rootDir,fileDir))
}

#***************************************************************************
# First section is to look for the path and establish the working directory. 
# From there:
# 'getDirNFile1' will look for the path (regular windows path) to the raster
# file (in this case a folder from windows explorer perspective), it will not 
# remove any extension
#***************************************************************************
getDirNFile1 <- function(inputFileDir1 ){
  #GET AND SET ROOT DIR AND FILE DIR
  DIR=unlist(strsplit(inputFileDir1,"",fixed = TRUE))
  TokenPos=1:length(DIR)
  TokenPosMatch=TokenPos[DIR=="\\"]
  rootDir=paste0(DIR[1:TokenPosMatch[length(TokenPosMatch)]],collapse="")
  fileDir=paste0(DIR[(TokenPosMatch[length(TokenPosMatch)]+1):length(DIR)],collapse="")
  setwd(rootDir)   #setup a working directory (i.e. where data are saved)
  
  return(c(rootDir,fileDir))
}

Distance <- function(inputFileDir,                  ##Input Feature Class (Shape file)
                     poligonConstrainFileDir,       ##Input Constraint Feature Class (Shape file)
                     outputFileDir,                 ##Output File - Distance
                     isWater,                       ##Water or Land feature analysis
                     fieldConstrainDir_u,           ##Input Direction File (Raster file - Zonal)
                     fieldConstrainDir_v,           ##Input Direction File (Raster file - Meridional)
                     maxAng,                        ##Select Max. Angle
                     Dmax,                          ##Select Max. Distance
                     RowStnd,                       ##Row standardization
                     Dmax1, InvPower, Knn, dir, cb  ##unused argument(s)
){

  #************************
  # LOAD GIS Data
  #************************
  td <- "."        # This option will separate name and extension apart
  
  # -*/-*/-*/-*/-*/-*/-*/-*/
  # LOAD SIGHTINGS
  # -*/-*/-*/-*/-*/-*/-*/-*/
  fileDir=getDirNFile(inputFileDir)[2]
  sightings <- readOGR(td, fileDir)
  
  
  # -*/-*/-*/-*/-*/-*/-*/-*/
  # LOAD CONSTRAINED
  # -*/-*/-*/-*/-*/-*/-*/-*/
  fileDir=getDirNFile(poligonConstrainFileDir)[2]
  land <- readOGR(td, fileDir)
  
  
  #************************
  # CREATE NET
  #************************
  
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  #   CREATE ADJACENCY MATRIX
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  sn=length(sightings)
  # everything connected to everything
  adjMat=matrix(1,nrow=sn,ncol=sn);
  diag(adjMat)=0;
  
  g <- graph.adjacency(adjMat, mode=c("undirected"), weighted=NULL)
  
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  # Extracting Coordinates from points
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  coords <- matrix(coordinates(sightings),ncol=2)
  
  #----------------------------------------------------------
  # Extracting minimum distance to "prevent" islands
  #----------------------------------------------------------
  IDs<-row.names(as(sightings, "data.frame"))
  sight_kn1 <- knn2nb(knearneigh(coords, k=1), row.names=IDs)
  distnb <- unlist(nbdists(sight_kn1, coords))
  max_k1 <- max(distnb)
  
  # GET ALL THE COMBINATIONS BETWEEN POINTS
  nodeIndex=combinations(sn, 2, 1:sn, repeats.allowed=FALSE)
  
  
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  # RECIPROCITY OF NODES
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  # -----------------------------
  nodeIndex=rbind(nodeIndex[,],nodeIndex[,2:1])

  
  # CALC EUCLIDIAN DISTANCES AMONG ALL POINTS
  # ((x,1-x,2 )^2+(y,1-y,2 )^2 )
  D=((coords[nodeIndex[,1],1]-coords[nodeIndex[,2],1])^2+
       (coords[nodeIndex[,1],2]-coords[nodeIndex[,2],2])^2)^(1/2)
  
  
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  #  CREATE NET LINES
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  # coords[nodeIndex[i,1],1]--> NODE1-X-->X,1
  # coords[nodeIndex[i,2],1]--> NODE1-Y-->Y,1
  # coords[nodeIndex[i,1],2]--> NODE2-X-->X,2
  # coords[nodeIndex[i,2],2]--> NODE2-Y-->Y,2
  
  lineList=list()
  linesList=list()
  linesCount=dim(nodeIndex)[1]
  for(i in 1:linesCount){
    c=cbind(c(coords[nodeIndex[i,1],1],coords[nodeIndex[i,2],1]),c(coords[nodeIndex[i,1],2],coords[nodeIndex[i,2],2]))
    l <- Line(c)
    lineList=list(l)
    Ls = Lines(lineList, ID = as.character(i))
    linesList[i]=Ls
  }
  
  SL = SpatialLines(linesList,proj4string=CRS(proj4string(sightings)))
  SLDF = SpatialLinesDataFrame(SL,data.frame(LINK_ID = c(1:linesCount),row.names = c(1:linesCount)))
  gc(TRUE) #- get rid of trash >.<
  
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  # ADD FIELDS TO STORE LINK PROPERTIES
  # NODE NODE_INDEX
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  
  SLDF$NODE1=c(nodeIndex[,1])
  SLDF$NODE2=c(nodeIndex[,2])
  
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  # DISTANCE
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  SLDF$DIST=c(D)
  SLDF$D_F=SLDF$DIST<=Dmax #--> In here we defined threshold distance
  
  
  if (isWater==TRUE){
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    # LAND CONSTRAINED
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    overLand = as.matrix(over(SLDF, geometry(land), returnList = TRUE))
    isIntersected=as.matrix(overLand[,1]==1)
    isIntersected[is.na(isIntersected)]=FALSE
    SLDF$LAND_F=!c(isIntersected) #is not intersected by land
    
  } else {
    
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    # WATER CONSTRAINED
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    overLand = as.matrix(over(SLDF, geometry(land), returnList = TRUE))
    isIntersected=as.matrix(overLand[,1]==0)
    isIntersected[is.na(isIntersected)]=TRUE
    SLDF$LAND_F=!c(isIntersected) #is not intersected by WATER
    
  }

  
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  # CHECK IF DIRECTIONALITY RASTERS (CURRENTS)
  # ARE PRESENT
  # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
  
  ##########################################
  # To debug only this code (line by line) 
  # use the following:
  #----------------------------------------
  #   if (file.exists(fieldConstrainDir_u)==TRUE &
  #         file.exists(fieldConstrainDir_v)==TRUE &
  #         (maxAng>0)==TRUE){
  #----------------------------------------
  ##########################################
  
  ##########################################
  # To this code as a function 
  # use the following:
  #----------------------------------------
  #   if ((fieldConstrainDir_u>0)==TRUE &
  #         (fieldConstrainDir_v>0)==TRUE &
  #         (maxAng>0)==TRUE){
  #----------------------------------------
  ##########################################
  
  if ((fieldConstrainDir_u>0)==TRUE &
        (fieldConstrainDir_v>0)==TRUE &
        (maxAng>0)==TRUE){
    
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    #  Directionality SECTION
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    
    # Velocity field
    fileDir=getDirNFile1(fieldConstrainDir_u)[2]
    field_u <- raster(fileDir)
    fileDir=getDirNFile1(fieldConstrainDir_v)[2]
    field_v <- raster(fileDir)
    
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    #  EXTRACT VELOCITY FIELD VALUES (RASTER-->POINT)
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    node_field_u=extract(field_u,sightings)
    node_field_v=extract(field_v,sightings)
    # FIELD IN NODE 1
    SLDF$NODE1_U=c(as.matrix(node_field_u[nodeIndex[,1]]))
    SLDF$NODE1_V=c(as.matrix(node_field_v[nodeIndex[,1]]))
    # FIELD IN NODE 2
    SLDF$NODE2_U=c(as.matrix(node_field_u[nodeIndex[,2]]))
    SLDF$NODE2_V=c(as.matrix(node_field_v[nodeIndex[,2]]))
    
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    # FLOW CONSTRAINED
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    # Cauchy-Schwarz inequality
    # <VectorNode1.VectorNode2>/||VectorNode1|| ||VectorNode2||
    # "F" or "f" specifies the Frobenius norm (the Euclidean norm of x treated as if it were a vector)
    CSI=matrix(0,nrow=linesCount,ncol=1)
    for(i in 1:linesCount){
      CSI[i]=(SLDF$NODE1_U[i]*SLDF$NODE2_U[i]+SLDF$NODE1_V[i]*SLDF$NODE2_V[i])/
        (norm(as.matrix(c(SLDF$NODE1_U[i],SLDF$NODE1_V[i])), "F")*(norm(as.matrix(c(SLDF$NODE2_U[i],SLDF$NODE2_V[i])), "F")))
    }
    #  round to few decimals
    fixPres=1000000
    CSI=round(CSI*fixPres)/fixPres
    alpha=acos(CSI)
    
    SLDF$VEC_ANG=c(alpha)*(180/pi)#CONVERT ANGLE TO DEGREES
    SLDF$ANG_F=SLDF$VEC_ANG<=maxAng
    fileDir=getDirNFile1(outputFileDir)[2]
    writeOGR(SLDF, "Nb", paste(fileDir,"_CompleteLinks_DistAngle"), driver="ESRI Shapefile")
    
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    # BOOLEAN INFERENCE
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    selected=SLDF$ANG_F&SLDF$LAND_F&SLDF$D_F
    
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    # CREATE OUTPUT
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    OUTPUT_1=SLDF[selected,c("LINK_ID","NODE1","NODE2","DIST")]
    
    cat("\nCompleteLinks_DistAngle shapefile created", "\n")
    
  } else {
    fileDir=getDirNFile1(outputFileDir)[2]
    writeOGR(SLDF, "Nb", paste(fileDir,"_CompleteLinks_Dist"), driver="ESRI Shapefile")
    
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    # BOOLEAN INFERENCE
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    selected=SLDF$LAND_F&SLDF$D_F
    
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    # CREATE OUTPUT
    # -*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/-*/
    OUTPUT_1=SLDF[selected,c("LINK_ID","NODE1","NODE2","DIST")]
    
    cat("\nCompleteLinks_Dist shapefile created", "\n")
    
  }
  
  OUTPUT_1$WG=1

if (RowStnd==TRUE){

  #------------------------------------------------
  # ROW STANDARDIZED
  #------------------------------------------------
  NeighborClusters=unique(OUTPUT_1$NODE1)
  CLUSTER=matrix(0,nrow=length(OUTPUT_1$NODE1),ncol=1)
  CLUSTER_D_W=matrix(0,nrow=length(OUTPUT_1$NODE1),ncol=1)
  ones=matrix(1,nrow=length(OUTPUT_1$NODE1),ncol=1)
  # FOR EACH CLUSTER WEIGHT DISTANCE
  for(i in 1:length(NeighborClusters)){
    clusterIndex=OUTPUT_1$NODE1==NeighborClusters[i]
    CLUSTER[clusterIndex]=i
    CLUSTER_D_W[clusterIndex]=OUTPUT_1$DIST[clusterIndex]/sum(OUTPUT_1$DIST[clusterIndex])
    
  }
  # Insert columns
  OUTPUT_1$CLU=c(CLUSTER)
  OUTPUT_1$WEIGHT=c(CLUSTER_D_W)
  OUTPUT_1$CLU_D_W_I=c(ones-CLUSTER_D_W)
  
  OUTPUT=OUTPUT_1[c("NODE1","NODE2","WEIGHT")]
  names(OUTPUT)[1] <- paste("OBJECTID")
  names(OUTPUT)[2] <- paste("NID")
  
  cat("\nRow standardization computed", "\n")
  
} else {

  OUTPUT=OUTPUT_1[c("NODE1","NODE2","WG")]
  names(OUTPUT)[1] <- paste("OBJECTID")
  names(OUTPUT)[2] <- paste("NID")
  names(OUTPUT)[3] <- paste("WEIGHT")
  
}
  

  #####----------------------------------------------------------
  #   SAVE OUTPUT FILE
  # -----------------------------
  #Distance shaefile and csv
  #####----------------------------------------------------------
  fileDir=getDirNFile1(outputFileDir)[2]
  writeOGR(OUTPUT, "Nb", fileDir, driver="ESRI Shapefile")
  
  cat("\nWeight Matrix:",fileDir, "(shp file), has been created", "\n")
  
  cat("\nNeighbourhood Type: Fixed Distance Band - completed", "\n")
  
  cat("\nMinimum distance to have at least one neighbours is:", max_k1, "\nSmaller distances may contain 'islands'", "\n")
  
  gc(TRUE) #- get rid of trash >.<
  
  return(OUTPUT)
  
}