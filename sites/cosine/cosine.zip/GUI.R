#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-
# 
# Find out if required packages have been install, if not, then proceed to install them
# 
#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-

list.of.packages <- c("gWidgets", "gWidgetsRGtk2", "maptools", "raster", "spdep", "sp", 
                      "geoR", "igraph", "spatstat", "gtools", "rgeos", 
                      "SDMTools", "rgdal", "fgui")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)

require(gWidgets)
options("guiToolkit"="RGtk2")

#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-


################------------------------------------------------------------------------------
#
# Change the path for your neighbourhood type:
# - Distance.r
# - Inverse_Distance.r
# - Knn.r
#
################------------------------------------------------------------------------------

Distance_source="C:/Users/.../R/Distance.r"
InverseDistance_source="C:/Users/.../R/Inverse_Distance.r"
Knn_source="C:/Users/.../R/Knn.r"


###########################################################################
#
#FUNCTIONS
#
###########################################################################

Distance <- function(inputFileDir=character(0), poligonConstrainFileDir=character(0),
                     outputFileDir=character(0), isWater=character(0), fieldConstrainDir_u=character(0),
                     fieldConstrainDir_v=character(0), maxAng=character(0),
                     Dmax=character(0),Dmax1=character(0), InvPower=character(0),
                     Knn=character(0), dir=character(0), cb=character(0),RowStnd=character(0),...){
  print(list(inputFileDir=inputFileDir, poligonConstrainFileDir=poligonConstrainFileDir,
             outputFileDir=outputFileDir, isWater=isWater, fieldConstrainDir_u=fieldConstrainDir_u,
             fieldConstrainDir_v=fieldConstrainDir_v, maxAng=maxAng,
             Dmax=Dmax,Dmax1=Dmax1, InvPower=InvPower,Knn=Knn, dir=dir, cb=cb, RowStnd=RowStnd))
}

Inverse_Distance <- function(inputFileDir=character(0), poligonConstrainFileDir=character(0),
                             outputFileDir=character(0), isWater=character(0), fieldConstrainDir_u=character(0),
                             fieldConstrainDir_v=character(0), maxAng=character(0),
                             Dmax1=character(0), InvPower=character(0), Dmax=character(0), 
                             Knn=character(0), dir=character(0), cb=character(0), RowStnd=character(0),...){
  print(list(inputFileDir=inputFileDir, poligonConstrainFileDir=poligonConstrainFileDir,
             outputFileDir=outputFileDir, isWater=isWater, fieldConstrainDir_u=fieldConstrainDir_u,
             fieldConstrainDir_v=fieldConstrainDir_v, maxAng=maxAng,
             Dmax1=Dmax1, InvPower=InvPower, Dmax=Dmax, Knn=Knn, dir=dir, cb=cb, RowStnd=RowStnd))
}

Knn <- function(inputFileDir=character(0), poligonConstrainFileDir=character(0),
                outputFileDir=character(0), isWater=character(0), fieldConstrainDir_u=character(0),
                fieldConstrainDir_v=character(0), maxAng=character(0),
                Knn=character(0), Dmax=character(0), Dmax1=character(0), 
                InvPower=character(0), dir=character(0), cb=character(0), RowStnd=character(0),...){
  print(list(inputFileDir=inputFileDir, poligonConstrainFileDir=poligonConstrainFileDir,
             outputFileDir=outputFileDir, isWater=isWater, fieldConstrainDir_u=fieldConstrainDir_u,
             fieldConstrainDir_v=fieldConstrainDir_v, maxAng=maxAng,
             Knn=Knn, Dmax=Dmax, Dmax1=Dmax1, InvPower=InvPower, dir=dir, cb=cb, RowStnd=RowStnd))
}

l <- list()

###########################################################################
#
#Layout
#
###########################################################################

w <- gwindow("COSINE PACKAGE")
g <- ggroup(cont = w, horizontal = FALSE)
g1 <- ggroup(horizontal = FALSE, cont = g, expand = TRUE)


##
fr0 <- gframe ( "Input/Output", cont = g, horizontal=FALSE )
ly0 <- glayout ( cont = fr0 , expand = TRUE )

##
ly0 [2,1] <- inputFileDir <- glabel("Input Feature Class:", cont = ly0)
ly0 [2,2] <- (l$inputFileDir <- gfilebrowse (text = "Select a shapefile...", type = "open", quote = FALSE,
                                             filter = list("Shapefiles" = list(patterns = c("*.shp"))), 
                                             cont = ly0))

ly0 [3,1] <- poligonConstrainFileDir <- glabel("Input Constraint Feature Class:", cont = ly0)
ly0 [3,2] <- (l$poligonConstrainFileDir <- gfilebrowse (text = "Select a shapefile...", type = "open", quote = FALSE,
                                                        filter = list("Shapefiles" = list(patterns = c("*.shp"))), 
                                                        cont = ly0))

ly0 [4,1] <- outputFileDir <- glabel("Output file name:", cont = ly0)
ly0 [4,2] <- (l$outputFileDir <- gfilebrowse (text = "Select a name...", type = "save", quote = FALSE,
                                              filter = list("Shapefiles" = list(patterns = c("*.shp"))), 
                                              cont = ly0))

ly0[5,1] <- (l$isWater <- gcheckbox("Water analysis? (If NO, then uncheck)", checked = TRUE, cont=ly0))


##
fr1 <- gframe ( "", cont = g, horizontal=FALSE )
ly1 <- glayout ( cont = fr1 , expand = TRUE )

ly1 [1,1] <- glabel ( "Direction?", cont = ly1)
ly1 [1,2] <- l$dir <- gcombobox ( c("No","Yes"), cont = ly1 )


##
ly2 <- glayout ( cont = fr1 , expand = TRUE )

##
ly2 [1,1] <- fieldConstrainDir_v <- glabel("Meridional (Raster file):", cont = ly2)
ly2 [1,2] <- (l$fieldConstrainDir_v <- gedit("0", initial.msg = "Paste the path to the raster file (no extensions)",
                                             cont = ly2))

ly2 [2,1] <- fieldConstrainDir_u <- glabel("Zonal (Raster file):", cont = ly2)
ly2 [2,2] <- (l$fieldConstrainDir_u <- gedit("0", initial.msg = "Paste the path to the raster file (no extensions)",
                                             cont = ly2))

ly21 <- glayout ( cont = fr1 , expand = TRUE )
ly21 [1,1,8] <- maxAng <- glabel("Max. Angle:", cont = ly21)
ly21 [1,8] <- (l$maxAng <- gedit("0", initial.msg = "Enter maximum angle between a pair of observations", 
                                 cont = ly21, coerce.with = as.numeric))

enabled(ly2) <- FALSE
enabled(ly21) <- FALSE


###########----------------------------------------
fr3 <- gframe ( "", cont = g, horizontal=FALSE )
ly3 <- glayout ( cont = fr3 , expand = TRUE )

ly3 [1,1,3] <- glabel("Neighbourhood Type: ", cont=ly3)
ly3 [1,3] <- l$cb <- gcombobox(c("Fixed Distance Band", "Inverse Distance","Knn"), cont=ly3)

ly4 <- glayout(cont=fr3)
ly4[1,1,3] <- "Threshold Distance:"
ly4[1,5] <- (l$Dmax <- gedit("0",cont = ly4, coerce.with = as.numeric))

ly5 <- glayout(cont=fr3)
ly5[1,1,3] <- "Threshold Distance:"
ly5[1,5] <- (l$Dmax1 <- gedit("0",cont = ly5, coerce.with = as.numeric))

ly5[1,8] <- "Power:"
ly5[1,9] <- (l$InvPower <- gspinbutton(from=1, to=2, by=1, cont = ly5))

ly6 <- glayout(cont=fr3)
ly6[1,1,3] <- "K-Nearest Neighbours: "
ly6[1,3] <- (l$Knn <- gedit("0",cont = ly6, coerce.with = as.numeric))



ly7 <- glayout(cont=fr3)
ly7[1,1] <- (l$RowStnd <- gcheckbox("Row standardization (Optional)", checked = FALSE, cont=ly7))

enabled(ly5) <- FALSE
enabled(ly6) <- FALSE

###########---------------------------------
#
#Size text
#
###########---------------------------------

## Input/Output
size ( l$inputFileDir ) <- c ( 200,20)
size ( l$poligonConstrainFileDir ) <- c ( 200,20)
size ( l$outputFileDir ) <- c ( 200,20)

## Direction
size ( l$fieldConstrainDir_v ) <- c ( 250,20)
size ( l$fieldConstrainDir_u ) <- c ( 250,20)
size ( l$maxAng ) <- c ( 30,20)

## Neighbourhood
size ( l$Dmax ) <- c ( 50,20)
size ( l$Dmax1 ) <- c ( 50,20)
size ( l$InvPower ) <- c ( 40,20)
size ( l$Knn ) <- c ( 50,20)

###########---------------------------------
#
#Buttons
#
###########---------------------------------

ly8 <- glayout(cont=g)

ly8[4,9,13] <-btnfn <- gbutton("      OK       ", cont=ly8)
ly8[4,12,16] <- cbtn <- gbutton("  Cancel  ", container = ly8, handler = function(j,...) dispose(w))


###########################################################################
#
#Handler options ("gray out")
#
###########################################################################

addHandlerChanged(l$dir, handler=function(h,...) {
  val <- svalue(h$obj)
  enabled(ly2) <- val == "Yes"
  enabled(ly21) <- val == "Yes"
})


addHandlerChanged(l$cb, handler=function(h,...) {
  val <- svalue(h$obj)
  enabled(ly4) <- val == "Fixed Distance Band"
  enabled(ly5) <- val == "Inverse Distance"
  enabled(ly6) <- val == "Knn"
})


#############################################################################
#
# Function to run Constraint script 
#  (Function in another R script)
#
#############################################################################

addHandlerClicked(btnfn, handler=function(h,...) {
  lst <- sapply(l, svalue, simplify=FALSE) ## a list of values
  dispose(w)
  if (lst$cb == "Fixed Distance Band"){
    cat ("\nNeighbourhood Type: Fixed Distance Band", "\n\n")
    
    Distance <- capture.output(with(list(inputFileDir=lst$inputFileDir, poligonConstrainFileDir=lst$poligonConstrainFileDir,
                                         outputFileDir=lst$outputFileDir, isWater=lst$isWater, fieldConstrainDir_u=lst$fieldConstrainDir_u,
                                         fieldConstrainDir_v=lst$fieldConstrainDir_v, maxAng=lst$maxAng,
                                         Dmax=lst$Dmax, RowStnd=lst$RowStnd), source(Distance_source)))
    do.call("Distance", lst)
  }else if (lst$cb == "Inverse Distance"){
    cat ("\nNeighbourhood Type: Inverse Distance", "\n\n")
    
    Inverse_Distance <- capture.output(with(list(inputFileDir=lst$inputFileDir, poligonConstrainFileDir=lst$poligonConstrainFileDir,
                                                 outputFileDir=lst$outputFileDir, isWater=lst$isWater, fieldConstrainDir_u=lst$fieldConstrainDir_u,
                                                 fieldConstrainDir_v=lst$fieldConstrainDir_v, maxAng=lst$maxAng,
                                                 Dmax1=lst$Dmax1, InvPower=lst$InvPower, RowStnd=lst$RowStnd), source(InverseDistance_source)))
    do.call("Inverse_Distance", lst)
  }else if (lst$cb == "Knn"){
    cat ("\nNeighbourhood Type: Knn", "\n\n")
    
    Knn <- capture.output(with(list(inputFileDir=lst$inputFileDir, poligonConstrainFileDir=lst$poligonConstrainFileDir,
                                    outputFileDir=lst$outputFileDir, isWater=lst$isWater, fieldConstrainDir_u=lst$fieldConstrainDir_u,
                                    fieldConstrainDir_v=lst$fieldConstrainDir_v, maxAng=lst$maxAng,
                                    Knn=lst$Knn, RowStnd=lst$RowStnd), source(Knn_source)))
    do.call("Knn", lst)
  }
  
}
)