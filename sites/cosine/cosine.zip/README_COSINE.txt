PRE-PROCESSING
- It is highly recommended that user install RStudio
- Once installed, user can open the GUI interface, select all (ctrl+A) R code for the GUI and run it, no need to run line by line
- When asked to install GTK+, click Yes (ok)
- It is recommended that the observation (points) and constraint (polyline) shapefile be located under the same folder

User needs to create an OBJECTID column, if already exists, is appropriate to delete current OBJECTID and create one. 
To do this:
1. User must create column name 'OBJECTID' with LONG (Data type) and precision 9 (no need to enter precision)
2. Calculate new OBJECTID column as follow: [FID] +1


PROCEDURE to work with ArcGIS for Spatial weights Matrix
1. Open the .DBF file (in Excel) from the newly create shape file
2. From the first row, Delete: NID and WEIGHT column names, LEAVE ONLY OBJECTID
3. Select "Save As type" and choose Other Formats. From the Other Formats choices, select Formatted Text (Space delimited)(*.prn).
4. Choose a location for the file and click SAVE.
5. If a warning message is displayed, click YES
6. In ArcGIS, Open Your analysis method, and Under Conceptualization of Spatial Relationships, select "GET_SPATIAL_WEIGHTS_FROM_FILE"
7. Under "Weights Matrix File (optional)" parameter, locate and select the  file with (.prn) extension you have created in steps 1-5

More help: http://wiki.answers.com/Q/How_do_you_convert_a_excel_file_to_an_ASCII_file_with_fixed_length_fields

PROCEDURE to work with GEODA for Spatial weights Matrix
GeoDA structure for spatial weight matrix requires to have in the first line of the matrix the following structure:
"0" "Total Number of Features" "Source Feature Class (Name of the point shapefile)" "Unique ID Field Name (OBJECTID)" 
0 131 Oil_Spill_Pacific_2008 OBJECTID

NOTE: The requirement of OBJECTID is OBJECTID will be used to link the IDs from the Source Feature Class (point shapefile)
and the spatial weight matrix, OBJECTID must match on both features.
R reads data.frame of the shapefile (FID in ArcGIS), and spatial statistics tools in ArcGIS and GeoDA requires a 
Source_ID for the weight matrix (OBJECTID).


Explanation of Fields:
- Input Constraint Feature Class:  Requires polygon shapefile.
- Output file name:  will create a matrix weight shapefile and an additional shapefile 'CompleteLinks'.
- Water analysis? (If NO, then uncheck):  This checkbox evaluates whether the analysis is for aquatic or terrestrial environment 
	(if terrestrial, then uncheck it).
- Zonal (Raster file):  Raster file - Zonal direction is towards East (if velocity is negative, then will go towards West).
- Meridional (Raster file):  Raster file - Meridional direction is towards North (if velocity is negative, then will go towards South).
- Max. Angle:  Maximum angle between Zonal and Meridional direction to be considered in the same flow direction.
- Threshold Distance:  Select maximum (threshold) distance (Distance or Inverse Distance) for observations to be considered neighbours.
- Power:  Power value for Inverse Distance (1,2).
- K-Nearest Neighbours:  Select Number of Nearest Neighbours (KNN).
- Row standardization:  Recommended whenever feature distribution is potentially biased due to sampling design or to an imposed aggregation 
	scheme.  Checked-Spatial weights are standardized by row. Each weight is divided by its row sum. Unchecked-No standardization of spatial 
	weights is applied.
